-- Main menu background: famous venues (parody versions) at night with a slowly circling camera.
-- One scene is built at a time; they rotate every ~25 seconds.
local RunService = game:GetService("RunService")
local Lighting = game:GetService("Lighting")
local Root = script:FindFirstAncestor("Headliner")
local UI = require(Root.Client.UI)

local New = UI.New
local MenuScene = {}

local ORIGIN = Vector3.new(0, 0, -9000)
local WARM = Color3.fromRGB(255, 214, 140)
local CONCRETE = Color3.fromRGB(96, 98, 106)
local ASPHALT = Color3.fromRGB(34, 35, 40)

------------------------------------------------------------------ helpers
local folder
local rng = Random.new(42)

local function P(name, size, cf, color, material, extra)
	local p = New("Part", {
		Name = name,
		Size = size,
		CFrame = cf,
		Color = color,
		Material = material or Enum.Material.SmoothPlastic,
		Anchored = true,
		CanCollide = false,
		CanQuery = false,
		CanTouch = false,
		TopSurface = Enum.SurfaceType.Smooth,
		BottomSurface = Enum.SurfaceType.Smooth,
		Parent = folder,
	})
	if extra then
		for k, v in pairs(extra) do
			p[k] = v
		end
	end
	return p
end

local function cylV(name, h, d, pos, color, material)
	return P(name, Vector3.new(h, d, d), CFrame.new(pos) * CFrame.Angles(0, 0, math.pi / 2), color, material, { Shape = Enum.PartType.Cylinder })
end

-- a thin bar between two points
local function bar(name, a, b, thick, color, material)
	local len = (b - a).Magnitude
	return P(name, Vector3.new(thick, thick, len), CFrame.lookAt((a + b) / 2, b), color, material or Enum.Material.Metal)
end

local function sign(part, face, text, textColor, bg, font)
	local gui = New("SurfaceGui", { Face = face, SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud, PixelsPerStud = 12, LightInfluence = 0, Brightness = 2.5, Parent = part })
	local f = New("Frame", { Size = UDim2.fromScale(1, 1), BackgroundColor3 = bg or Color3.new(0, 0, 0), BackgroundTransparency = bg and 0 or 1, BorderSizePixel = 0, Parent = gui })
	New("TextLabel", {
		Size = UDim2.fromScale(0.94, 0.8),
		Position = UDim2.fromScale(0.03, 0.1),
		BackgroundTransparency = 1,
		Text = text,
		TextScaled = true,
		Font = font or Enum.Font.GothamBlack,
		TextColor3 = textColor or Color3.new(1, 1, 1),
		Parent = f,
	})
	return gui
end

local function lamp(pos)
	P("LampPole", Vector3.new(0.6, 14, 0.6), CFrame.new(pos + Vector3.new(0, 7, 0)), Color3.fromRGB(40, 42, 48), Enum.Material.Metal)
	local head = P("LampHead", Vector3.new(2.2, 0.6, 1.2), CFrame.new(pos + Vector3.new(0, 14, 0)), WARM, Enum.Material.Neon)
	New("PointLight", { Range = 26, Brightness = 1.6, Color = WARM, Shadows = false, Parent = head })
end

-- skyscraper with lit window bands
local function tower(pos, w, d, h, color, roofLight)
	P("Tower", Vector3.new(w, h, d), CFrame.new(pos + Vector3.new(0, h / 2, 0)), color, Enum.Material.Glass, { Reflectance = 0.15 })
	local floors = math.floor(h / 9)
	for f = 1, floors do
		if rng:NextNumber() < 0.8 then
			local y = pos.Y + f * 9 - 3
			local c = WARM:Lerp(Color3.fromRGB(170, 210, 255), rng:NextNumber())
			local glow = 0.15 + rng:NextNumber() * 0.5
			P("Windows", Vector3.new(w + 0.2, 1.6, d + 0.2), CFrame.new(pos.X, y, pos.Z), c, Enum.Material.Neon, { Transparency = glow })
		end
	end
	if roofLight then
		P("RoofBlink", Vector3.new(1.2, 1.2, 1.2), CFrame.new(pos + Vector3.new(0, h + 2, 0)), Color3.fromRGB(255, 40, 40), Enum.Material.Neon)
	end
end

local function cityRing(center, innerR, outerR, count, palette, avoid)
	for _ = 1, count do
		for _ = 1, 10 do
			local a = rng:NextNumber() * math.pi * 2
			local r = innerR + rng:NextNumber() * (outerR - innerR)
			local x, z = math.cos(a) * r, math.sin(a) * r
			if not avoid or not avoid(x, z) then
				local h = 50 + rng:NextNumber() ^ 2 * 190
				tower(center + Vector3.new(x, 0, z), 26 + rng:NextInteger(0, 22), 26 + rng:NextInteger(0, 22), h, palette[rng:NextInteger(1, #palette)], h > 160)
				break
			end
		end
	end
end

local SHIRTS = { Color3.fromRGB(20, 20, 24), Color3.fromRGB(230, 230, 235), Color3.fromRGB(200, 40, 60), Color3.fromRGB(40, 90, 200), Color3.fromRGB(250, 200, 50), Color3.fromRGB(150, 60, 200) }
local SKINS = { Color3.fromRGB(255, 220, 190), Color3.fromRGB(234, 184, 146), Color3.fromRGB(198, 134, 94), Color3.fromRGB(141, 85, 54) }

-- a queue of fans (some hold glowing signs in the artist colour)
local function fans(center, rows, cols, spacing, artistColor, faceYaw)
	local list = {}
	local base = CFrame.new(center) * CFrame.Angles(0, faceYaw or 0, 0)
	for i = 0, rows - 1 do
		for j = 0, cols - 1 do
			local off = Vector3.new((j - cols / 2) * spacing + rng:NextNumber() - 0.5, 0, i * spacing + rng:NextNumber() - 0.5)
			local pos = (base * CFrame.new(off)).Position
			local shirt = (rng:NextNumber() < 0.35) and artistColor or SHIRTS[rng:NextInteger(1, #SHIRTS)]
			local body = P("Fan", Vector3.new(1.6, 2.8, 1), CFrame.new(pos + Vector3.new(0, 1.4, 0)), shirt)
			local head = P("FanHead", Vector3.new(1.3, 1.3, 1.3), CFrame.new(pos + Vector3.new(0, 3.45, 0)), SKINS[rng:NextInteger(1, #SKINS)], nil, { Shape = Enum.PartType.Ball })
			table.insert(list, { body = body, head = head, base = pos, ph = rng:NextNumber() * 6.28 })
			if rng:NextNumber() < 0.12 then
				P("FanSign", Vector3.new(2.4, 1.4, 0.15), CFrame.new(pos + Vector3.new(0, 5.4, 0)) * CFrame.Angles(0, faceYaw or 0, 0), artistColor, Enum.Material.Neon)
			end
		end
	end
	return list
end

local function banner(pos, text, color, yaw)
	P("FlagPole", Vector3.new(0.5, 26, 0.5), CFrame.new(pos + Vector3.new(0, 13, 0)), Color3.fromRGB(180, 182, 190), Enum.Material.Metal)
	local b = P("Banner", Vector3.new(6, 16, 0.2), CFrame.new(pos + Vector3.new(3.4, 16, 0)) * CFrame.Angles(0, yaw or 0, 0), color, Enum.Material.Fabric)
	sign(b, Enum.NormalId.Front, text, Color3.new(1, 1, 1))
	sign(b, Enum.NormalId.Back, text, Color3.new(1, 1, 1))
end

local function ground(center, size, color, material)
	P("Ground", Vector3.new(size, 2, size), CFrame.new(center + Vector3.new(0, -1, 0)), color, material or Enum.Material.Concrete)
end

------------------------------------------------------------------ scenes
local SCENES = {}

-- THE O3 (London): white tent dome with yellow masts by the river
SCENES[1] = {
	name = "The O3 Arena",
	city = "London",
	tonight = "NOVA RAY",
	color = Color3.fromRGB(255, 105, 180),
	radius = 330,
	build = function(c)
		ground(c, 1600, Color3.fromRGB(44, 46, 52))
		P("River", Vector3.new(1600, 1, 170), CFrame.new(c + Vector3.new(0, 0.05, -300)), Color3.fromRGB(16, 30, 52), Enum.Material.Glass, { Reflectance = 0.35 })
		P("Plaza", Vector3.new(280, 0.3, 120), CFrame.new(c + Vector3.new(0, 0.1, 170)), CONCRETE, Enum.Material.Pavement)
		-- dome
		P("Dome", Vector3.new(232, 78, 232), CFrame.new(c), Color3.fromRGB(238, 236, 230), Enum.Material.Fabric, { Shape = Enum.PartType.Ball })
		cylV("DomeBase", 6, 234, c + Vector3.new(0, 3, 0), Color3.fromRGB(150, 152, 160), Enum.Material.Metal)
		for i = 0, 11 do
			local a = i * math.pi / 6 + 0.13
			local dir = Vector3.new(math.cos(a), 0, math.sin(a))
			local foot = c + dir * 96
			local top = c + dir * 118 + Vector3.new(0, 108, 0)
			bar("Mast", foot, top, 3.2, Color3.fromRGB(255, 196, 0), Enum.Material.Metal)
			P("MastLight", Vector3.new(2, 2, 2), CFrame.new(top + Vector3.new(0, 1.5, 0)), Color3.fromRGB(255, 60, 60), Enum.Material.Neon)
			for _, k in ipairs({ -0.18, 0.18 }) do
				local d2 = Vector3.new(math.cos(a + k), 0, math.sin(a + k))
				bar("Cable", top - dir * 4, c + d2 * 66 + Vector3.new(0, 30, 0), 0.35, Color3.fromRGB(210, 210, 215))
			end
		end
		-- entrance with name and screen
		P("Entrance", Vector3.new(70, 18, 22), CFrame.new(c + Vector3.new(0, 9, 118)), Color3.fromRGB(120, 170, 220), Enum.Material.Glass, { Transparency = 0.35 })
		P("EntranceGlow", Vector3.new(70, 1, 22), CFrame.new(c + Vector3.new(0, 18.5, 118)), Color3.fromRGB(80, 160, 255), Enum.Material.Neon)
		local nameBoard = P("NameBoard", Vector3.new(60, 11, 1), CFrame.new(c + Vector3.new(0, 26, 129)), Color3.fromRGB(10, 20, 60))
		sign(nameBoard, Enum.NormalId.Back, "THE O3", Color3.new(1, 1, 1), Color3.fromRGB(10, 30, 90))
		local screen = P("Screen", Vector3.new(34, 14, 1), CFrame.new(c + Vector3.new(-70, 14, 150)), Color3.new(0, 0, 0))
		sign(screen, Enum.NormalId.Back, "NOVA RAY\nLIVE TONIGHT", Color3.new(1, 1, 1), Color3.fromRGB(200, 40, 140))
		P("ScreenPost", Vector3.new(1, 8, 1), CFrame.new(c + Vector3.new(-70, 4, 150)), Color3.fromRGB(40, 40, 46), Enum.Material.Metal)
		-- across the river: tall towers (Canary Wharf-ish)
		local center = c + Vector3.new(0, 0, -520)
		tower(center, 44, 44, 240, Color3.fromRGB(70, 90, 120), true)
		P("Pyramid", Vector3.new(30, 30, 30), CFrame.new(center + Vector3.new(0, 250, 0)) * CFrame.Angles(math.rad(45), 0, math.rad(45)), Color3.fromRGB(150, 160, 175), Enum.Material.Metal)
		cityRing(center, 50, 260, 22, { Color3.fromRGB(50, 70, 100), Color3.fromRGB(70, 80, 95), Color3.fromRGB(40, 50, 70) })
		cityRing(c, 330, 600, 18, { Color3.fromRGB(60, 62, 70), Color3.fromRGB(80, 70, 66) }, function(x, z)
			return z < -150
		end)
		for i = -4, 4 do
			lamp(c + Vector3.new(i * 30, 0, 190))
		end
		local f = fans(c + Vector3.new(0, 0, 145), 6, 22, 3.2, Color3.fromRGB(255, 105, 180), math.pi)
		for i, a in ipairs({ "NOVA RAY", "STARLYTE", "IRONCLAD", "LUNA SOL" }) do
			banner(c + Vector3.new(-100 + i * 40, 0, 210), a, ({ Color3.fromRGB(255, 105, 180), Color3.fromRGB(150, 90, 255), Color3.fromRGB(120, 120, 130), Color3.fromRGB(255, 120, 60) })[i], 0)
		end
		return f
	end,
}

-- MADISON CIRCLE GARDEN (New York): round drum between skyscrapers, taxis, marquee
SCENES[2] = {
	name = "Madison Circle Garden",
	city = "New York",
	tonight = "STARLYTE",
	color = Color3.fromRGB(150, 90, 255),
	radius = 300,
	build = function(c)
		ground(c, 1600, ASPHALT, Enum.Material.Asphalt)
		-- sidewalks / blocks
		for _, z in ipairs({ -1, 1 }) do
			P("Sidewalk", Vector3.new(1600, 0.4, 20), CFrame.new(c + Vector3.new(0, 0.2, z * 120)), CONCRETE, Enum.Material.Pavement)
			P("Sidewalk", Vector3.new(20, 0.4, 1600), CFrame.new(c + Vector3.new(z * 125, 0.2, 0)), CONCRETE, Enum.Material.Pavement)
		end
		P("Plaza", Vector3.new(220, 0.4, 220), CFrame.new(c + Vector3.new(0, 0.15, 0)), Color3.fromRGB(80, 80, 86), Enum.Material.Pavement)
		-- the drum
		cylV("Drum", 50, 172, c + Vector3.new(0, 25, 0), Color3.fromRGB(176, 170, 158), Enum.Material.Concrete)
		for i = 0, 47 do
			local a = i * math.pi * 2 / 48
			local p = c + Vector3.new(math.cos(a) * 86.5, 25, math.sin(a) * 86.5)
			P("Fin", Vector3.new(1.6, 50, 3.4), CFrame.new(p) * CFrame.Angles(0, -a, 0), Color3.fromRGB(205, 200, 190), Enum.Material.Concrete)
		end
		cylV("RoofRing", 4, 178, c + Vector3.new(0, 52, 0), Color3.fromRGB(70, 72, 78), Enum.Material.Metal)
		P("RoofDome", Vector3.new(168, 18, 168), CFrame.new(c + Vector3.new(0, 52, 0)), Color3.fromRGB(110, 112, 120), Enum.Material.Metal, { Shape = Enum.PartType.Ball })
		cylV("GlowRing", 1, 174, c + Vector3.new(0, 48, 0), Color3.fromRGB(150, 90, 255), Enum.Material.Neon)
		-- entrance pavilion with marquee
		P("Pavilion", Vector3.new(80, 22, 26), CFrame.new(c + Vector3.new(0, 11, 98)), Color3.fromRGB(60, 80, 110), Enum.Material.Glass, { Transparency = 0.3 })
		local marquee = P("Marquee", Vector3.new(76, 10, 2), CFrame.new(c + Vector3.new(0, 27, 112)), Color3.new(0, 0, 0))
		sign(marquee, Enum.NormalId.Back, "MADISON CIRCLE GARDEN", Color3.new(1, 1, 1), Color3.fromRGB(20, 20, 30))
		local led = P("LED", Vector3.new(40, 14, 1.4), CFrame.new(c + Vector3.new(80, 20, 112)), Color3.new(0, 0, 0))
		sign(led, Enum.NormalId.Back, "STARLYTE\nSOLD OUT", Color3.new(1, 1, 1), Color3.fromRGB(110, 60, 220))
		P("LEDPost", Vector3.new(1.4, 13, 1.4), CFrame.new(c + Vector3.new(80, 6.5, 112)), Color3.fromRGB(40, 40, 46), Enum.Material.Metal)
		-- office tower behind
		tower(c + Vector3.new(0, 0, -150), 90, 50, 210, Color3.fromRGB(40, 60, 90), true)
		cityRing(c, 160, 620, 46, { Color3.fromRGB(70, 74, 84), Color3.fromRGB(100, 86, 74), Color3.fromRGB(56, 66, 86), Color3.fromRGB(120, 116, 110) }, function(x, z)
			return math.abs(x) < 140 or math.abs(z) < 135
		end)
		-- yellow taxis on the avenues
		for i = 1, 14 do
			local along = -500 + i * 70
			local horizontal = i % 2 == 0
			local pos = horizontal and Vector3.new(along, 2, 135 + (i % 3) * 6) or Vector3.new(140 + (i % 3) * 6, 2, along)
			local taxi = P("Taxi", Vector3.new(6, 3, 12), CFrame.new(c + pos) * CFrame.Angles(0, horizontal and math.pi / 2 or 0, 0), Color3.fromRGB(255, 200, 20))
			P("TaxiTop", Vector3.new(5, 1.6, 6), taxi.CFrame * CFrame.new(0, 2.3, 0), Color3.fromRGB(30, 30, 36), Enum.Material.Glass)
			P("TaxiLight", Vector3.new(2, 0.5, 0.6), taxi.CFrame * CFrame.new(0, 3.4, 0), Color3.fromRGB(255, 250, 200), Enum.Material.Neon)
		end
		for i = -3, 3 do
			lamp(c + Vector3.new(i * 32, 0, 122))
		end
		local f = fans(c + Vector3.new(-30, 0, 118), 5, 24, 3.2, Color3.fromRGB(150, 90, 255), math.pi)
		for i, a in ipairs({ "STARLYTE", "VELVET JUNE", "KAI RIVERS" }) do
			banner(c + Vector3.new(-120 + i * 34, 0, 128), a, ({ Color3.fromRGB(150, 90, 255), Color3.fromRGB(170, 90, 230), Color3.fromRGB(255, 190, 40) })[i], 0)
		end
		return f
	end,
}

-- LANXUS ARENA (Cologne): glass hall under a huge steel arch, cathedral across the Rhine
SCENES[3] = {
	name = "Lanxus Arena",
	city = "Cologne",
	tonight = "IRONCLAD",
	color = Color3.fromRGB(170, 170, 180),
	radius = 320,
	build = function(c)
		ground(c, 1600, Color3.fromRGB(46, 48, 54))
		P("Rhine", Vector3.new(220, 1, 1600), CFrame.new(c + Vector3.new(330, 0.05, 0)), Color3.fromRGB(18, 34, 50), Enum.Material.Glass, { Reflectance = 0.35 })
		P("Forecourt", Vector3.new(260, 0.3, 90), CFrame.new(c + Vector3.new(0, 0.1, 120)), CONCRETE, Enum.Material.Pavement)
		-- hall
		P("Hall", Vector3.new(190, 46, 150), CFrame.new(c + Vector3.new(0, 23, 0)), Color3.fromRGB(70, 92, 112), Enum.Material.Glass, { Reflectance = 0.2 })
		for y = 8, 44, 12 do
			P("Band", Vector3.new(191, 1.2, 151), CFrame.new(c + Vector3.new(0, y, 0)), Color3.fromRGB(170, 175, 185), Enum.Material.Metal)
		end
		P("Roof", Vector3.new(196, 3, 156), CFrame.new(c + Vector3.new(0, 47.5, 0)), Color3.fromRGB(60, 62, 68), Enum.Material.Metal)
		-- the arch
		local last = nil
		for i = 0, 28 do
			local a = math.pi * i / 28
			local p = c + Vector3.new(-128 * math.cos(a), 104 * math.sin(a), 0)
			if last then
				bar("Arch", last, p, 5, Color3.fromRGB(215, 218, 226))
				if i % 3 == 0 and p.Y > 52 then
					bar("Hanger", p, Vector3.new(p.X, c.Y + 49, p.Z + 40), 0.4, Color3.fromRGB(200, 200, 210))
					bar("Hanger", p, Vector3.new(p.X, c.Y + 49, p.Z - 40), 0.4, Color3.fromRGB(200, 200, 210))
				end
			end
			last = p
		end
		local nameBoard = P("NameBoard", Vector3.new(80, 10, 1), CFrame.new(c + Vector3.new(0, 38, 76)), Color3.new(0, 0, 0))
		sign(nameBoard, Enum.NormalId.Back, "LANXUS ARENA", Color3.new(1, 1, 1), Color3.fromRGB(150, 20, 30))
		local screen = P("Screen", Vector3.new(36, 12, 1), CFrame.new(c + Vector3.new(0, 18, 76.5)), Color3.new(0, 0, 0))
		sign(screen, Enum.NormalId.Back, "IRONCLAD - FORGED IN FIRE TOUR", Color3.new(1, 1, 1), Color3.fromRGB(60, 60, 70))
		-- cathedral with two spires across the river
		local cath = c + Vector3.new(560, 0, -60)
		P("Nave", Vector3.new(60, 50, 150), CFrame.new(cath + Vector3.new(0, 25, 0)), Color3.fromRGB(60, 58, 56), Enum.Material.Slate)
		for _, dz in ipairs({ -60, -20 }) do
			local base = cath + Vector3.new(0, 0, dz - 30)
			P("Spire", Vector3.new(26, 90, 26), CFrame.new(base + Vector3.new(0, 45, 0)), Color3.fromRGB(64, 60, 58), Enum.Material.Slate)
			P("Spire2", Vector3.new(18, 40, 18), CFrame.new(base + Vector3.new(0, 110, 0)), Color3.fromRGB(64, 60, 58), Enum.Material.Slate)
			P("Spire3", Vector3.new(9, 34, 9), CFrame.new(base + Vector3.new(0, 147, 0)), Color3.fromRGB(64, 60, 58), Enum.Material.Slate)
			P("Tip", Vector3.new(2, 14, 2), CFrame.new(base + Vector3.new(0, 171, 0)), Color3.fromRGB(64, 60, 58), Enum.Material.Slate)
			New("SpotLight", { Face = Enum.NormalId.Top, Angle = 40, Range = 60, Brightness = 2, Color = WARM, Parent = P("Floodlight", Vector3.new(2, 1, 2), CFrame.new(base + Vector3.new(0, 1, 18)), WARM, Enum.Material.Neon) })
		end
		-- railway bridge across the Rhine
		for k = 0, 2 do
			local x0 = c.X + 230 + k * 70
			local lastP = nil
			for i = 0, 10 do
				local a = math.pi * i / 10
				local p = Vector3.new(x0 + 35 - 35 * math.cos(a), c.Y + 12 + 26 * math.sin(a), c.Z - 230)
				if lastP then
					bar("BridgeArch", lastP, p, 1.6, Color3.fromRGB(90, 110, 100))
				end
				lastP = p
			end
		end
		P("BridgeDeck", Vector3.new(230, 3, 14), CFrame.new(c + Vector3.new(335, 12, -230)), Color3.fromRGB(70, 72, 76), Enum.Material.Metal)
		cityRing(c, 260, 560, 24, { Color3.fromRGB(90, 82, 76), Color3.fromRGB(70, 72, 80) }, function(x, z)
			return x > 200
		end)
		for i = -4, 4 do
			lamp(c + Vector3.new(i * 28, 0, 160))
		end
		local f = fans(c + Vector3.new(0, 0, 100), 6, 26, 3.2, Color3.fromRGB(170, 170, 180), math.pi)
		for i, a in ipairs({ "IRONCLAD", "THE RUSTY WIRES", "NEON HARBOR" }) do
			banner(c + Vector3.new(-90 + i * 45, 0, 168), a, ({ Color3.fromRGB(90, 90, 100), Color3.fromRGB(230, 90, 60), Color3.fromRGB(60, 200, 160) })[i], 0)
		end
		return f
	end,
}

------------------------------------------------------------------ control
local conn = nil
local atmosphere = nil

local function setLighting()
	Lighting.ClockTime = 20.3
	Lighting.Brightness = 1.6
	Lighting.Ambient = Color3.fromRGB(70, 72, 96)
	Lighting.OutdoorAmbient = Color3.fromRGB(96, 98, 130)
	Lighting.GlobalShadows = false
	if not atmosphere then
		atmosphere = New("Atmosphere", { Density = 0.32, Offset = 0.15, Color = Color3.fromRGB(150, 160, 205), Decay = Color3.fromRGB(90, 70, 130), Glare = 0.3, Haze = 1.6, Parent = Lighting })
	end
end

-- onScene(scene) is called whenever the shown venue changes (for the caption)
function MenuScene.start(onScene)
	MenuScene.stop()
	setLighting()
	local index = 0
	local t, sceneT = 0, 0
	local crowd = {}
	local scene = nil
	local function nextScene()
		if folder then
			folder:Destroy()
		end
		index = index % #SCENES + 1
		scene = SCENES[index]
		folder = New("Folder", { Name = "MenuScene", Parent = workspace })
		crowd = scene.build(ORIGIN) or {}
		sceneT = 0
		if onScene then
			onScene(scene)
		end
	end
	nextScene()
	conn = RunService.RenderStepped:Connect(function(dt)
		t = t + dt
		sceneT = sceneT + dt
		if sceneT > 26 then
			nextScene()
		end
		-- slowly circling camera, the venue sits on the right side of the screen (menu on the left)
		local a = sceneT * 0.07 + index
		local r = scene.radius
		local camPos = ORIGIN + Vector3.new(math.sin(a) * r, 70 + math.sin(sceneT * 0.25) * 12, math.cos(a) * r)
		local look = (ORIGIN + Vector3.new(0, 30, 0) - camPos).Unit
		local right = look:Cross(Vector3.new(0, 1, 0)).Unit
		local cam = workspace.CurrentCamera
		cam.CameraType = Enum.CameraType.Scriptable
		cam.FieldOfView = 55
		cam.CFrame = CFrame.lookAt(camPos, ORIGIN + Vector3.new(0, 30, 0) - right * 95)
		-- fans bounce a little
		for i, f in ipairs(crowd) do
			if i % 2 == math.floor(t * 4) % 2 then
				local j = math.max(0, math.sin(t * 6 + f.ph)) * 0.6
				f.body.CFrame = CFrame.new(f.base + Vector3.new(0, 1.4 + j, 0))
				f.head.CFrame = CFrame.new(f.base + Vector3.new(0, 3.45 + j, 0))
			end
		end
	end)
end

function MenuScene.stop()
	if conn then
		conn:Disconnect()
		conn = nil
	end
	if folder then
		folder:Destroy()
		folder = nil
	end
	if atmosphere then
		atmosphere:Destroy()
		atmosphere = nil
	end
end

return MenuScene
